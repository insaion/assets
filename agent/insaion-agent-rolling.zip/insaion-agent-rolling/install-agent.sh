#!/bin/bash

# Exit on any error
set -e

# --- Helper Functions ---
function find_agent_deb() {
  local search_dir="${1-.}" # Default to current directory if no argument
  local deb_file
  deb_file=$(find "$search_dir" -maxdepth 1 -name '*cpp-agent*.deb' -print -quit)
  if [[ -z "$deb_file" ]]; then
    echo "ERROR: No *cpp-agent*.deb file found in $search_dir." >&2
    exit 1
  fi
  echo "$deb_file"
}

# --- Main Installation Logic ---

echo "Starting Insaion Agent installation..."


# Install dependencies: telegraf and gettext-base (for envsubst)
echo "Updating package lists..."
sudo apt-get update
echo "Installing telegraf and gettext-base..."
sudo apt install -y curl gettext-base
curl --silent --location -O \
https://repos.influxdata.com/influxdata-archive.key \
&& echo "943666881a1b8d9b849b74caebf02d3465d6beb716510d86a39f6c8e8dac7515  influxdata-archive.key" \
| sha256sum -c - && cat influxdata-archive.key \
| gpg --dearmor \
| sudo tee /etc/apt/trusted.gpg.d/influxdata-archive.gpg > /dev/null \
&& echo 'deb [signed-by=/etc/apt/trusted.gpg.d/influxdata-archive.gpg] https://repos.influxdata.com/debian stable main' \
| sudo tee /etc/apt/sources.list.d/influxdata.list
sudo apt-get update && sudo apt-get install telegraf

# Find and install the C++ agent .deb package
echo "Searching for C++ agent .deb package..."
AGENT_DEB_FILE=$(find_agent_deb .) # Search in the current directory
echo "Found agent package: $AGENT_DEB_FILE"

echo "Installing $AGENT_DEB_FILE..."
sudo dpkg -i "$AGENT_DEB_FILE"

sudo mkdir -p /var/lib/insaion-agent

echo "Insaion Agent installation completed successfully."
